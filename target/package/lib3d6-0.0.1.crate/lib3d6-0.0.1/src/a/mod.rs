pub fn test_3() {
    println!("Test function 3 called");
}