#[cfg(test)]
mod tests {
    #[test]
    fn test_1() {
        lib3d6::test_4();
        lib3d6::test_1();
    }
}